package de.keno.buildffa;

import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import com.google.common.collect.Maps;

import de.bwtraining.serverapi.ServerAPI;
import de.keno.buildffa.command.StatsCommand;
import de.keno.buildffa.data.ServerData;
import de.keno.buildffa.data.StatsData;
import de.keno.buildffa.inventory.InventoryManager;
import de.keno.buildffa.kit.KitManager;
import de.keno.buildffa.listener.BlockChangeListener;
import de.keno.buildffa.listener.EntityDamageListener;
import de.keno.buildffa.listener.FoodLevelChangeListener;
import de.keno.buildffa.listener.InventoryClickListener;
import de.keno.buildffa.listener.PlayerCloseInventory;
import de.keno.buildffa.listener.PlayerDeathListener;
import de.keno.buildffa.listener.PlayerDropItemListener;
import de.keno.buildffa.listener.PlayerInteractListener;
import de.keno.buildffa.listener.PlayerJoinListener;
import de.keno.buildffa.listener.PlayerPickupItemListener;
import de.keno.buildffa.listener.PlayerQuitListener;
import de.keno.buildffa.listener.PlayerRespawnListener;
import de.keno.buildffa.player.PlayerManager;
import de.keno.buildffa.scoreboard.ScoreboardManager;
import de.keno.buildffa.stats.StatsManager;
import de.keno.buildffa.countdown.BlockCountdown;
import de.keno.buildffa.countdown.MoveCountdown;

public class BuildFFA extends JavaPlugin {
	
	private static BuildFFA instance;
	private String prefix = "�6�lBuildFFA �8� �7";
	private String modus;
	
	private ScoreboardManager scoreboardManager;
	private StatsManager statsManager;
	private KitManager kitManager;
	private PlayerManager playerManager;
	private ServerData serverData;
	private InventoryManager inventoryManager;
	
	private Map<Location, Long> blockLocations = Maps.newHashMap();
	private Map<UUID, StatsData> playerStats = Maps.newHashMap();
	
	@Override
	public void onEnable() {
		instance = this;
		
		saveDefaultConfig();
		
		Bukkit.createWorld(new WorldCreator("world"));
		Bukkit.getWorlds().add(Bukkit.getWorld("world"));
		
		this.scoreboardManager = new ScoreboardManager();
		this.statsManager = new StatsManager();
		this.modus = getConfig().getString("Modus");
		this.kitManager = new KitManager();
		this.playerManager = new PlayerManager();
		
		this.serverData = new ServerData();
		this.inventoryManager = new InventoryManager();
		
		ServerAPI.getInstance().addCountdownTask(new MoveCountdown(), 10);
		ServerAPI.getInstance().addCountdownTask(new BlockCountdown(), 1);
		
		setExecutors();
		registerListener();
		registerCommands();
		spawnVillager();
	}
	
	@Override
	public void onDisable() {
		for(Player player : Bukkit.getOnlinePlayers()) {
			if(playerStats.containsKey(player.getUniqueId())) {
				statsManager.savePlayerStats(player.getUniqueId());
			}
		}
	}
	
	@Override
	public void onLoad() {

	}
	
	private void spawnVillager() {
		ServerAPI.getInstance().getExecutorService().submit(() ->{
			try {
				Thread.sleep(1*4999);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			Bukkit.getScheduler().callSyncMethod(ServerAPI.getInstance(), () ->{
				serverData.createVillager();
				return null;
			});
		});
	}
	
	private void setExecutors() {
		ServerAPI.getInstance().setJoinExecutor(new PlayerJoinListener());
		ServerAPI.getInstance().setQuitExecutor(new PlayerQuitListener());
	}
	
	private void registerCommands() {
		getCommand("stats").setExecutor(new StatsCommand());
	}
	
	private void registerListener() {
		getServer().getPluginManager().registerEvents(new EntityDamageListener(), this);
		getServer().getPluginManager().registerEvents(new FoodLevelChangeListener(), this);
		getServer().getPluginManager().registerEvents(new InventoryClickListener(), this);
		getServer().getPluginManager().registerEvents(new PlayerDeathListener(), this);
		getServer().getPluginManager().registerEvents(new PlayerInteractListener(), this);
		getServer().getPluginManager().registerEvents(new PlayerRespawnListener(), this);
		getServer().getPluginManager().registerEvents(new PlayerDropItemListener(), this);
		getServer().getPluginManager().registerEvents(new PlayerPickupItemListener(), this);
		getServer().getPluginManager().registerEvents(new PlayerCloseInventory(), this);
		getServer().getPluginManager().registerEvents(new BlockChangeListener(), this);
	}
	
	public static BuildFFA getInstance() {
		return instance;
	}
	
	public InventoryManager getInventoryManager() {
		return inventoryManager;
	}
	
	public String getModus() {
		return modus;
	}
	
	public String getPrefix() {
		return prefix;
	}
	
	public ServerData getServerData() {
		return serverData;
	}
	
	public Map<Location, Long> getBlockLocations() {
		return blockLocations;
	}
	
	public KitManager getKitManager() {
		return kitManager;
	}
	
	public PlayerManager getPlayerManager() {
		return playerManager;
	}
	
	public StatsManager getStatsManager() {
		return statsManager;
	}
	
	public Map<UUID, StatsData> getPlayerStats() {
		return playerStats;
	}
	
	public ScoreboardManager getScoreboardManager() {
		return scoreboardManager;
	}

}
