package de.keno.buildffa.scoreboard;

import java.util.Map;
import java.util.UUID;

import org.bukkit.entity.Player;

import com.google.common.collect.Maps;

import de.keno.buildffa.BuildFFA;
import de.keno.buildffa.data.StatsData;

public class ScoreboardManager {

	private Map<UUID, ScoreboardPacket> scoreboardData = Maps.newHashMap();
	
	public void sendScoreboard(Player player) {
		UUID uuid = player.getUniqueId();
		if(scoreboardData.containsKey(uuid)) {
			scoreboardData.get(uuid).remove();
			scoreboardData.remove(uuid);
		}
		scoreboardData.put(uuid, getLobbyScoreboardPacket(player));
	}
	
	public void removeFromScoreboard(Player player) {
		if(scoreboardData.containsKey(player.getUniqueId())) {
			scoreboardData.remove(player.getUniqueId());
		}
	}
	
	public void updateScoreboardKills(Player player) {
		if(scoreboardData.containsKey(player.getUniqueId())) {
			StatsData statsData = BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId());
			
			ScoreboardPacket scoreboardPacket = scoreboardData.get(player.getUniqueId());
			scoreboardPacket.removeLine(6);
			scoreboardPacket.setLine(6, " �7� �b�a" + statsData.getKills());
			scoreboardPacket.removeLine(0);
			scoreboardPacket.setLine(0, " �7� �c�a" + statsData.getKD());
		}
	}
	
	public void updateScoreboardDeaths(Player player) {
		if(scoreboardData.containsKey(player.getUniqueId())) {
			StatsData statsData = BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId());
			
			ScoreboardPacket scoreboardPacket = scoreboardData.get(player.getUniqueId());
			scoreboardPacket.removeLine(3);
			scoreboardPacket.setLine(3, " �7� �a" + statsData.getDeaths());
			scoreboardPacket.removeLine(0);
			scoreboardPacket.setLine(0, " �7� �c�a" + statsData.getKD());
		}
	}
	
	private ScoreboardPacket getLobbyScoreboardPacket(Player player) {
		StatsData statsData = BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId());
		ScoreboardPacket scoreboardPacket = new ScoreboardPacket(player);
		scoreboardPacket.sendSidebar("   �6�lBuildFFA   ");
		scoreboardPacket.setLine(11, "�e");
		scoreboardPacket.setLine(10, "�7Modus:");
		if(BuildFFA.getInstance().getModus().equalsIgnoreCase("KitBuildFFA")) {
			scoreboardPacket.setLine(9, " �7� �d�aKit-BuildFFA");
		} else {
			scoreboardPacket.setLine(9, " �7� �d�aOldschool");
		}
		scoreboardPacket.setLine(8, "�d");
		scoreboardPacket.setLine(7, "�7Kills:");
		scoreboardPacket.setLine(6, " �7� �b�a" + statsData.getKills());
		scoreboardPacket.setLine(5, "�c");
		scoreboardPacket.setLine(4, "�7Deaths:");
		scoreboardPacket.setLine(3, " �7� �a" + statsData.getDeaths());
		scoreboardPacket.setLine(2, "�b");
		scoreboardPacket.setLine(1, "�7KD:");
		scoreboardPacket.setLine(0, " �7� �c�a" + statsData.getKD());
		return scoreboardPacket;
	}
	
}
