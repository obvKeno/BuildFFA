package de.keno.buildffa.countdown;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import de.bwtraining.serverapi.ServerAPI;
import de.bwtraining.serverapi.countdown.Countdown;
import de.keno.buildffa.BuildFFA;
import de.keno.buildffa.data.ServerData;
import de.keno.buildffa.data.StatsData;

public class MoveCountdown implements Countdown {

	private ServerData serverData = BuildFFA.getInstance().getServerData();
	
	@Override
	public void executeTask() {
		for(Player player : Bukkit.getOnlinePlayers()) {
			if(!ServerAPI.getInstance().getSpectatorManager().containsPlayer(player)) {
				if(BuildFFA.getInstance().getPlayerStats().containsKey(player.getUniqueId())) {
					StatsData statsData = BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId());
					
					if(serverData.getDeathLocation() != null) {
						if(player.getLocation().getY() < serverData.getDeathLocation().getY()) {
							player.setHealth(0);
						}
					}
					if(serverData.getDropLocation() != null) {
						if(player.getLocation().getY() < serverData.getDropLocation().getY()) {
							if(!statsData.isItemsSet()) {
								statsData.setItemsSet(true);
								
								BuildFFA.getInstance().getPlayerManager().updatePlayerInventory(player, statsData.getKit());
							}
						}
					}
					if(serverData.getSpawnLocation() != null) {
						if(player.getLocation().distance(serverData.getSpawnLocation()) > 1000) {
							player.teleport(serverData.getSpawnLocation());
						}
					}
				}
			}
		}
		ServerAPI.getInstance().setPermaActionBar("�cTeaming ist nicht erlaubt");
	}

}
