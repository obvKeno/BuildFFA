package de.keno.buildffa.countdown;

import java.util.List;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import de.bwtraining.serverapi.ServerAPI;
import de.bwtraining.serverapi.countdown.Countdown;
import de.keno.buildffa.BuildFFA;

public class BlockCountdown implements Countdown {

	@Override
	public void executeTask() {
		if(BuildFFA.getInstance().getBlockLocations().size() != 0) {
			List<Location> deleteLocations = Lists.newArrayList();
			Map<Location, Long> updateLocations = Maps.newHashMap();
			
			for(Location location : BuildFFA.getInstance().getBlockLocations().keySet()) {
				Long time = BuildFFA.getInstance().getBlockLocations().get(location);
				
				if(time < System.currentTimeMillis()) {
					if(location.getBlock().getType() == Material.SANDSTONE) {
						Bukkit.getScheduler().callSyncMethod(ServerAPI.getInstance(), () ->{
							location.getBlock().setType(Material.RED_SANDSTONE);
							return null;
						});
						updateLocations.put(location.clone(), (System.currentTimeMillis() + 3 * 1000));
					} else {
						Bukkit.getScheduler().callSyncMethod(ServerAPI.getInstance(), () ->{
							location.getBlock().setType(Material.AIR);
							return null;
						});
						deleteLocations.add(location.clone());
					}
				}
			}
			
			for(Location location : updateLocations.keySet()) {
				BuildFFA.getInstance().getBlockLocations().put(location, updateLocations.get(location));
			}
			for(Location location : deleteLocations) {
				BuildFFA.getInstance().getBlockLocations().remove(location);
			}
		}
	}

}
