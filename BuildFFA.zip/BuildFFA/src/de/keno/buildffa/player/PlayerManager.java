package de.keno.buildffa.player;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;

import de.bwtraining.serverapi.ServerAPI;
import de.bwtraining.serverapi.builder.ItemBuilder;
import de.keno.buildffa.BuildFFA;
import de.keno.buildffa.data.StatsData;

public class PlayerManager {
	
	public void updatePlayerInventory(Player player, Boolean isNew) {
		if(!ServerAPI.getInstance().getSpectatorManager().containsPlayer(player)) {
			player.getInventory().clear();
			player.getInventory().setArmorContents(null);
			
			if(BuildFFA.getInstance().getModus().equalsIgnoreCase("KitBuildFFA")) {
				player.getInventory().setItem(4, ItemBuilder.modify().setMaterial(Material.CHEST).setDisplayName("�6Kits").buildItem());
			} else {
				if(isNew) {
					BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId()).setKit("Oldschool");
				}
			}
		}
	}
	
	public void updatePlayerInventory(Player player, String kit) {
		player.getInventory().clear();
		
		StatsData statsData = BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId());
		if(statsData.getInventoryData(kit) != null) {
			for(Integer integer : statsData.getInventoryData(kit).getInventoryStacks().keySet()) {
				player.getInventory().setItem(integer, statsData.getInventoryData(kit).getInventoryStacks().get(integer));
			}
		}
		player.getInventory().setHelmet(ItemBuilder.modify().setMaterial(Material.LEATHER_HELMET).setDisplayName("�6Helm").setUnbreakable(true).buildItem());
		player.getInventory().setChestplate(ItemBuilder.modify().setMaterial(Material.CHAINMAIL_CHESTPLATE).addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1).setDisplayName("�6Brustplatte").setUnbreakable(true).buildItem());
		player.getInventory().setLeggings(ItemBuilder.modify().setMaterial(Material.LEATHER_LEGGINGS).setDisplayName("�6Hose").setUnbreakable(true).buildItem());
		player.getInventory().setBoots(ItemBuilder.modify().setMaterial(Material.LEATHER_BOOTS).setDisplayName("�6Schuhe").setUnbreakable(true).buildItem());
	}

}
