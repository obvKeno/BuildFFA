package de.keno.buildffa.listener;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import de.bwtraining.serverapi.ServerAPI;
import de.bwtraining.serverapi.executor.JoinExecutor;
import de.keno.buildffa.BuildFFA;
import net.minecraft.server.v1_8_R3.PacketPlayOutWorldBorder;

public class PlayerJoinListener implements JoinExecutor {

	@Override
	public void executeJoin(Player player) {
		if(!ServerAPI.getInstance().getSpectatorManager().containsPlayer(player)) {
			player.setMaxHealth(20);
			player.setHealth(20);
			player.setFoodLevel(20);
			player.setGameMode(GameMode.SURVIVAL);
			player.getInventory().clear();
			player.getInventory().setArmorContents(null);
		}

		BuildFFA.getInstance().getServerData().createVillager();
		BuildFFA.getInstance().getStatsManager().loadPlayerStats(player, player.getUniqueId());
		if(BuildFFA.getInstance().getServerData().getSpawnLocation() != null) {
			player.teleport(BuildFFA.getInstance().getServerData().getSpawnLocation());
		}
		
		updateBorder(player);
	}
	
	public void updateBorder(Player player){
		Bukkit.getScheduler().callSyncMethod(ServerAPI.getInstance(), () ->{
			Location location = BuildFFA.getInstance().getServerData().getSpawnLocation();
	        net.minecraft.server.v1_8_R3.WorldBorder handle = new net.minecraft.server.v1_8_R3.WorldBorder();
	        handle.world = ((CraftWorld) player.getWorld()).getHandle();
	        handle.setCenter(location.getX(), location.getZ());
	        handle.setSize(280);

	        ((CraftPlayer) player).getHandle().playerConnection.sendPacket(new PacketPlayOutWorldBorder(handle, PacketPlayOutWorldBorder.EnumWorldBorderAction.INITIALIZE));
	        return null;
		});
    }

}
