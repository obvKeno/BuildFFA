package de.keno.buildffa.listener;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

import de.bwtraining.serverapi.builder.ItemBuilder;
import de.keno.buildffa.BuildFFA;

public class BlockChangeListener implements Listener {

	@EventHandler
	public void onBlockPlace(BlockPlaceEvent blockPlaceEvent) {
		if(blockPlaceEvent.getBlock().getLocation().getY() >= BuildFFA.getInstance().getServerData().getDropLocation().getY()) {
			blockPlaceEvent.setCancelled(true);
			return;
		}
		if(blockPlaceEvent.getBlock().getType() == Material.SANDSTONE) {
			blockPlaceEvent.getPlayer().setItemInHand(ItemBuilder.modify().setMaterial(Material.SANDSTONE).setAmount(64).setDisplayName("�6Block").buildItem());
			
			BuildFFA.getInstance().getBlockLocations().put(blockPlaceEvent.getBlock().getLocation(), (System.currentTimeMillis() + 3 * 1000));
		} else if(blockPlaceEvent.getBlock().getType() == Material.WEB) {
			BuildFFA.getInstance().getBlockLocations().put(blockPlaceEvent.getBlock().getLocation(), (System.currentTimeMillis() + 15 * 1000));
		}
	}
	
	@EventHandler
	public void onBlockBreak(BlockBreakEvent blockBreakEvent) {
		blockBreakEvent.setCancelled(true);
	}
	
}
