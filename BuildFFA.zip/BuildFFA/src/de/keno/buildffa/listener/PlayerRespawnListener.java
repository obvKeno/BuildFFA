package de.keno.buildffa.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

import de.keno.buildffa.BuildFFA;

public class PlayerRespawnListener implements Listener {
	
	@EventHandler
	public void onPlayerRespawn(PlayerRespawnEvent playerRespawnEvent) {
		playerRespawnEvent.setRespawnLocation(BuildFFA.getInstance().getServerData().getSpawnLocation());
		
		BuildFFA.getInstance().getPlayerManager().updatePlayerInventory(playerRespawnEvent.getPlayer(), false);
		BuildFFA.getInstance().getPlayerStats().get(playerRespawnEvent.getPlayer().getUniqueId()).setItemsSet(false);
	}

}
