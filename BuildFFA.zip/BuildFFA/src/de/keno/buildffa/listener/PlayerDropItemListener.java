package de.keno.buildffa.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;

import de.keno.buildffa.BuildFFA;

public class PlayerDropItemListener implements Listener {
	
	@EventHandler
	public void onPlayerDrop(PlayerDropItemEvent playerDropItemEvent) {
		if(playerDropItemEvent.getPlayer().getLocation().getY() > BuildFFA.getInstance().getServerData().getDropLocation().getY()) {
			if(playerDropItemEvent.getItemDrop() != null && playerDropItemEvent.getItemDrop().getItemStack() != null && playerDropItemEvent.getItemDrop().getItemStack().getItemMeta() != null) {
				if(!playerDropItemEvent.getItemDrop().getItemStack().getItemMeta().getDisplayName().equalsIgnoreCase("�6Kits")) {
					playerDropItemEvent.getItemDrop().remove();
				} else {
					playerDropItemEvent.setCancelled(true);
				}
			} else {
				playerDropItemEvent.setCancelled(true);
			}
		} else {
			playerDropItemEvent.setCancelled(true);
		}
	}

}
