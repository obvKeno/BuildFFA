package de.keno.buildffa.listener;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import com.google.common.collect.Maps;

import de.bwtraining.serverapi.ServerAPI;
import de.keno.buildffa.BuildFFA;
import de.keno.buildffa.data.StatsData;

public class PlayerCloseInventory implements Listener {
	
	@EventHandler
	public void onInventoryClose(InventoryCloseEvent inventoryCloseEvent) {
		List<String> kits = Arrays.asList("Spammer", "Rusher", "Oldschool", "Basedef");
		
		for(String string : kits) {
			if(inventoryCloseEvent.getInventory().getName().contains(string)) {
				ServerAPI.getInstance().getExecutorService().submit(() ->{
					saveInventory((Player) inventoryCloseEvent.getPlayer(), inventoryCloseEvent.getPlayer().getUniqueId(), string, inventoryCloseEvent.getInventory());
				});
 				return;
			}
		}
	}
	
	private void saveInventory(Player player, UUID uuid, String kit, Inventory closedInventory) {
		StatsData statsData = BuildFFA.getInstance().getPlayerStats().get(uuid);
		Map<Integer, ItemStack> stacks = Maps.newHashMap();
		for(Integer integer : statsData.getInventoryData(kit).getInventoryStacks().keySet()) {
			stacks.put(integer, statsData.getInventoryData(kit).getInventoryStacks().get(integer).clone());
		}
		statsData.clearInventoryData(kit);
		
		for(int i = 0; i < 36; i++) {
			if(closedInventory.getItem(i) != null && closedInventory.getItem(i).getItemMeta() != null) {
				statsData.addInventoryItemStack(kit, i, closedInventory.getItem(i));
			}
		}
		
		Collection<ItemStack> values = null;
		if(statsData.getInventoryData(kit).getInventoryStacks().size() != 0) {
			values = statsData.getInventoryData(kit).getInventoryStacks().values();
		}
		for(ItemStack itemStack : BuildFFA.getInstance().getKitManager().getKitData(kit).getDefaultItems().values()) {
			itemStack.setAmount(1);
			if(values.size() == 0 || !values.contains(itemStack)) {
				player.sendMessage(BuildFFA.getInstance().getPrefix() + "�cDeine Inventarsortierung konnte nicht gespeichert werden.");
				BuildFFA.getInstance().getPlayerManager().updatePlayerInventory(player, false);
				
				statsData.clearInventoryData(kit);
				for(Integer integer : stacks.keySet()) {
					statsData.addInventoryItemStack(kit, integer, stacks.get(integer));
				}
				return;
			}
		}
		
		player.sendMessage(BuildFFA.getInstance().getPrefix() + "�aDeine Inventarsortierung wurde erfolgreich gespeichert.");
	}

}
