package de.keno.buildffa.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.scheduler.BukkitRunnable;

import de.keno.buildffa.BuildFFA;

public class PlayerDeathListener implements Listener {
	
	@EventHandler
	public void onPlayerDeath(PlayerDeathEvent playerDeathEvent) {
		playerDeathEvent.setDroppedExp(0);
		playerDeathEvent.getDrops().clear();
		playerDeathEvent.setDeathMessage(null);
		
		Player entity = playerDeathEvent.getEntity();
		entity.teleport(BuildFFA.getInstance().getServerData().getSpawnLocation());
		
		if(entity.getKiller() != null) {
			Player killer = entity.getKiller();
			killer.setHealth(killer.getMaxHealth());
			
			for(Player player : Bukkit.getOnlinePlayers()) {
				player.sendMessage(BuildFFA.getInstance().getPrefix() + "�a" + entity.getName() + " �7wurde von �a" + killer.getName() + " �7get�tet.");
			}
			
			BuildFFA.getInstance().getPlayerStats().get(killer.getUniqueId()).addKill(killer);
			BuildFFA.getInstance().getScoreboardManager().updateScoreboardKills(killer);
		} else {
			for(Player player : Bukkit.getOnlinePlayers()) {
				player.sendMessage(BuildFFA.getInstance().getPrefix() + "�a" + entity.getName() + " �7ist gestorben.");
			}
		}
		
		BuildFFA.getInstance().getPlayerStats().get(entity.getUniqueId()).addDeath();
		BuildFFA.getInstance().getScoreboardManager().updateScoreboardDeaths(entity);
		
		new BukkitRunnable() {
			@Override
			public void run() {
				entity.spigot().respawn();
			}
		}.runTaskLater(BuildFFA.getInstance(), 2);
	}

}
