package de.keno.buildffa.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;

import de.keno.buildffa.BuildFFA;

public class InventoryClickListener implements Listener {
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent inventoryClickEvent) {
		Player player = (Player) inventoryClickEvent.getWhoClicked();
		
		if(inventoryClickEvent.getAction() == InventoryAction.DROP_ALL_CURSOR || inventoryClickEvent.getAction() == InventoryAction.DROP_ONE_CURSOR || inventoryClickEvent.getAction() == InventoryAction.DROP_ALL_SLOT || inventoryClickEvent.getAction() == InventoryAction.DROP_ONE_SLOT){
			inventoryClickEvent.setCancelled(true);
			return;
	    }
		if(inventoryClickEvent.getClick() == ClickType.NUMBER_KEY || inventoryClickEvent.getClick() == ClickType.WINDOW_BORDER_RIGHT 
				|| inventoryClickEvent.getClick() == ClickType.WINDOW_BORDER_LEFT || inventoryClickEvent.getClick() == ClickType.DOUBLE_CLICK 
				|| inventoryClickEvent.getClick() == ClickType.SHIFT_LEFT || inventoryClickEvent.getClick() == ClickType.SHIFT_RIGHT){
			inventoryClickEvent.setCancelled(true);
			return;
        }
		
		if(inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory() != player.getInventory()) {
			if(inventoryClickEvent.getCurrentItem() != null && inventoryClickEvent.getCurrentItem().getItemMeta() != null) {
				if(inventoryClickEvent.getClickedInventory().getName().equalsIgnoreCase("�6Kits")) {
					inventoryClickEvent.setCancelled(true);
					
					String displayName = inventoryClickEvent.getCurrentItem().getItemMeta().getDisplayName();
					displayName = displayName.replace("�6", "");
					
					if(!displayName.equalsIgnoreCase("Rusher") && !displayName.equalsIgnoreCase("Basedef") && !displayName.equalsIgnoreCase("Spammer")) {
						return;
					}
					player.closeInventory();
					player.sendMessage(BuildFFA.getInstance().getPrefix() + "�7Dein Kit wurde zu �6" + displayName + " �7gewechselt.");
					
					BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId()).setKit(displayName);
				} else if(inventoryClickEvent.getClickedInventory().getName().equalsIgnoreCase("�6Inventarsortierung")) {
					inventoryClickEvent.setCancelled(true);
					
					String displayName = inventoryClickEvent.getCurrentItem().getItemMeta().getDisplayName();
					displayName = displayName.replace("�6", "");
					
					if(!displayName.equalsIgnoreCase("Rusher") && !displayName.equalsIgnoreCase("Basedef") && !displayName.equalsIgnoreCase("Spammer") && !displayName.equalsIgnoreCase("Oldschool")) {
						return;
					}
					BuildFFA.getInstance().getInventoryManager().openSortierungInventory(player, displayName);
				}
				
				
			}
		} else if(inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory() == player.getInventory()) {
			inventoryClickEvent.setCancelled(true);
		}
	}

}
