package de.keno.buildffa.listener;

import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import de.keno.buildffa.BuildFFA;

public class PlayerInteractListener implements Listener {
	
	@EventHandler
	public void onPlayerInteract(PlayerInteractEvent playerInteractEvent) {
		Player player = playerInteractEvent.getPlayer();
		
		if(playerInteractEvent.getAction() == Action.RIGHT_CLICK_AIR || playerInteractEvent.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if(playerInteractEvent.getItem() != null && playerInteractEvent.getItem().getItemMeta() != null) {
				if(playerInteractEvent.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Kits")) {
					playerInteractEvent.setCancelled(true);
					
					BuildFFA.getInstance().getInventoryManager().openKitInventory(player);
				}
			}
			if(playerInteractEvent.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(playerInteractEvent.getClickedBlock() != null && playerInteractEvent.getClickedBlock().getType() == Material.ENDER_CHEST) {
					playerInteractEvent.setCancelled(true);
				}
			}
		}
	}
	
	@EventHandler
	public void onPlayerInteractAtEntity(PlayerInteractAtEntityEvent playerInteractAtEntityEvent) {
		playerInteractAtEntityEvent.setCancelled(true);
		
		//Entity entity = playerInteractAtEntityEvent.getRightClicked();
		//if(entity != null && entity instanceof Villager) {
		//	BuildFFA.getInstance().getInventoryManager().openInventarSortierungInventory(playerInteractAtEntityEvent.getPlayer());
		//}
	}
	
	@EventHandler
	public void onPlayerInteractEntity(PlayerInteractEntityEvent playerInteractEntityEvent) {
		playerInteractEntityEvent.setCancelled(true);
		
		Entity entity = playerInteractEntityEvent.getRightClicked();
		if(entity != null && entity instanceof Villager) {
			BuildFFA.getInstance().getInventoryManager().openInventarSortierungInventory(playerInteractEntityEvent.getPlayer());
		}
	}

}
