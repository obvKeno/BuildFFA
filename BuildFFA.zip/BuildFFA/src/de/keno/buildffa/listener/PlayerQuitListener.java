package de.keno.buildffa.listener;

import org.bukkit.entity.Player;

import de.bwtraining.serverapi.executor.QuitExecutor;
import de.keno.buildffa.BuildFFA;

public class PlayerQuitListener implements QuitExecutor {

	@Override
	public void executeQuit(Player player) {
		BuildFFA.getInstance().getStatsManager().savePlayerStats(player.getUniqueId());
		BuildFFA.getInstance().getScoreboardManager().removeFromScoreboard(player);
	}

}
