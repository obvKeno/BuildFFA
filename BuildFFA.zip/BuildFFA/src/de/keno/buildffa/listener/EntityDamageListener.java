package de.keno.buildffa.listener;

import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

import de.keno.buildffa.BuildFFA;

import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class EntityDamageListener implements Listener {
	
	@EventHandler
	public void onEntityDamage(EntityDamageEvent entityDamageEvent) {
		if(entityDamageEvent.getCause() == DamageCause.FALL) {
			entityDamageEvent.setCancelled(true);
			return;
		}
		
		if(BuildFFA.getInstance().getServerData().getDropLocation() != null) {
			if(entityDamageEvent.getEntity().getLocation().getY() > BuildFFA.getInstance().getServerData().getDropLocation().getY()) {
				entityDamageEvent.setCancelled(true);
				return;
			}
		}
	}

	@EventHandler
	public void onEntityDamageByEntity(EntityDamageByEntityEvent entityDamageByEntityEvent) {
		if(entityDamageByEntityEvent.getDamager() instanceof Arrow) {
			Arrow arrow = (Arrow) entityDamageByEntityEvent.getDamager();
			if(arrow.getShooter() != null && arrow.getShooter() instanceof Player) {
				Player shooter = (Player) arrow.getShooter();
				if(shooter.getUniqueId().toString().equals(entityDamageByEntityEvent.getEntity().getUniqueId().toString())) {
					entityDamageByEntityEvent.setCancelled(true);
					return;
				}
			}
		}
		
		if(BuildFFA.getInstance().getServerData().getDropLocation() != null) {
			if(entityDamageByEntityEvent.getEntity().getLocation().getY() > BuildFFA.getInstance().getServerData().getDropLocation().getY()) {
				entityDamageByEntityEvent.setCancelled(true);
				return;
			}
			if(entityDamageByEntityEvent.getDamager().getLocation().getY() > BuildFFA.getInstance().getServerData().getDropLocation().getY()) {
				entityDamageByEntityEvent.setCancelled(true);
				return;
			}
		}
	}
	
}
