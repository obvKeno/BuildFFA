package de.keno.buildffa.stats;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;

import org.bukkit.entity.Player;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import de.bwtraining.serverapi.ServerAPI;
import de.bwtraining.serverapi.fetcher.UUIDFetcher;
import de.keno.buildffa.BuildFFA;
import de.keno.buildffa.data.StatsData;
import de.keno.buildffa.kit.Kit;

public class StatsManager {
	
	public void sendPlayerStats(Player player, String playerName) {
		UUID uuid = UUIDFetcher.getUUID(playerName);
		if(uuid == null) {
			player.sendMessage(BuildFFA.getInstance().getPrefix() + "�cDer Spieler �e" + playerName + " �cwurde nicht gefunden.");
			return;
		}
		if(!BuildFFA.getInstance().getPlayerStats().containsKey(uuid)) {
			if(!new File("//home//Test-N//data//buildffa" + uuid + ".json").exists()) {
				player.sendMessage(BuildFFA.getInstance().getPrefix() + "�cDer Spieler �e" + playerName + " �cwurde nicht gefunden.");
				return;
			}
		}
		
		ServerAPI.getInstance().getExecutorService().submit(() ->{
			if(BuildFFA.getInstance().getPlayerStats().containsKey(uuid)) {
				sendStats(player, uuid, BuildFFA.getInstance().getPlayerStats().get(uuid));
			} else {
				File folder = new File("//home//BWTraining//data//buildffa");

				if (folder.isDirectory()) {
					JSONParser jsonParser = new JSONParser();

					try (FileReader fileReader = new FileReader("//home//BWTraining//data//buildffa" + uuid + ".json")) {
						JSONObject jsonObject = (JSONObject) jsonParser.parse(fileReader);
						
						StatsData statsData = new StatsData((long) jsonObject.get("Kills"), (long) jsonObject.get("Deaths"), "Spammer");
						sendStats(player, uuid, statsData);
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}
	
	private void sendStats(Player player, UUID uuid, StatsData statsData) {
		player.sendMessage(BuildFFA.getInstance().getPrefix() + "�7�m-----�r �6BuildFFA �7- �6Stats �7�m-----");
		player.sendMessage(BuildFFA.getInstance().getPrefix() + "�7Spielername: �6" + UUIDFetcher.getName(uuid));
		player.sendMessage(BuildFFA.getInstance().getPrefix() + "�7Kills: �6" + statsData.getKills());
		player.sendMessage(BuildFFA.getInstance().getPrefix() + "�7Deaths: �6" + statsData.getDeaths());
		player.sendMessage(BuildFFA.getInstance().getPrefix() + "�7KD: �6" + statsData.getKD());
		player.sendMessage(BuildFFA.getInstance().getPrefix() + "�7�m-----�r �6BuildFFA �7- �6Stats �7�m-----");
	}
	
	@SuppressWarnings("static-access")
	public void loadPlayerStats(Player player, UUID uuid) {
		ServerAPI.getInstance().getExecutorService().submit(() ->{
			if(!new File("//home//BWTraining//data//buildffa//" + uuid + ".json").exists()) {
				StatsData statsData = new StatsData(0, 0, "Spammer");
				
				for(String string : Arrays.asList("Spammer", "Rusher", "Oldschool", "Basedef")) {
					Kit kit = BuildFFA.getInstance().getKitManager().getKitData(string);
					
					for(Integer slot : kit.getDefaultItems().keySet()) {
						statsData.addInventoryItemStack(kit.getID(), slot, kit.getDefaultItems().get(slot));
					}
				}

				BuildFFA.getInstance().getPlayerStats().put(uuid, statsData);
				BuildFFA.getInstance().getScoreboardManager().sendScoreboard(player);
				BuildFFA.getInstance().getPlayerManager().updatePlayerInventory(player, true);
			} else {
				try {
					Thread.currentThread().sleep(1*499);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
				File folder = new File("//home//BWTraining//data//buildffa");

				if (folder.isDirectory()) {
					JSONParser jsonParser = new JSONParser();

					try (FileReader fileReader = new FileReader("//home//BWTraining//data//buildffa//" + uuid + ".json")) {
						JSONObject jsonObject = (JSONObject) jsonParser.parse(fileReader);
						
						StatsData statsData = new StatsData((long) jsonObject.get("Kills"), (long) jsonObject.get("Deaths"), "Spammer");
						
						for(String string : Arrays.asList("Spammer", "Rusher", "Oldschool", "Basedef")) {
							String data = (String) jsonObject.get(string);
							String[] items = data.split(":");
							
							for(int i = 0; i < items.length; i++) {
								String[] itemData = items[i].split(",");
								statsData.addInventoryItemStack(string, Integer.valueOf(itemData[1]), BuildFFA.getInstance().getKitManager().getItemStack(itemData[0]));
							}
						}
						
						BuildFFA.getInstance().getPlayerStats().put(uuid, statsData);
						BuildFFA.getInstance().getScoreboardManager().sendScoreboard(player);
						BuildFFA.getInstance().getPlayerManager().updatePlayerInventory(player, true);
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}
	
	@SuppressWarnings("unchecked")
	public void savePlayerStats(UUID uuid) {
		ServerAPI.getInstance().getExecutorService().submit(() ->{
			StatsData statsData = BuildFFA.getInstance().getPlayerStats().get(uuid);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("Kills", statsData.getKills());
			jsonObject.put("Deaths", statsData.getDeaths());
			
			for(String string : Arrays.asList("Spammer", "Rusher", "Oldschool", "Basedef")) {
				String kitData = "null";
				
				for(Integer integer : statsData.getInventoryData(string).getInventoryStacks().keySet()) {
					String itemName = BuildFFA.getInstance().getKitManager().getItemName(statsData.getInventoryData(string).getInventoryStacks().get(integer));
					if(kitData.equalsIgnoreCase("null")) {
						kitData = itemName + "," + integer;
					} else {
						kitData = kitData + ":" + itemName + "," + integer;
					}
				}
				
				jsonObject.put(string, kitData);
			}
				
			try (FileWriter fileWriter = new FileWriter("//home//BWTraining//data//buildffa//" + uuid + ".json")) {
				fileWriter.write(jsonObject.toJSONString());
				fileWriter.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			BuildFFA.getInstance().getPlayerStats().remove(uuid);
		});
	}

}
