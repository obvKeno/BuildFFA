package de.keno.buildffa.inventory;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import de.bwtraining.serverapi.builder.ItemBuilder;
import de.bwtraining.serverapi.inventory.InventoryCreator;
import de.keno.buildffa.BuildFFA;
import de.keno.buildffa.data.InventoryData;

public class InventoryManager {
	
	public void openKitInventory(Player player) {
		InventoryCreator inventoryCreator = InventoryCreator.createInventory("�6Kits", 3*9);
		inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.STAINED_GLASS_PANE).setData(5).setDisplayName("�0").buildItem(), 0,1,7,8,9,17,18,19,25,26);
		inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.STAINED_GLASS_PANE).setData(8).setDisplayName("�0").buildItem(), 2,3,4,5,6,20,21,22,23,24);
		
		inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.STICK).setDisplayName("�6Rusher").buildItem(), 10);
		inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.IRON_SWORD).setDisplayName("�6Basedef").buildItem(), 13);
		inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.BOW).setDisplayName("�6Spammer").buildItem(), 16);
		
		player.openInventory(inventoryCreator.getInventory());
	}
	
	public void openInventarSortierungInventory(Player player) {
		InventoryCreator inventoryCreator = InventoryCreator.createInventory("�6Inventarsortierung", 3*9);
		inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.STAINED_GLASS_PANE).setData(5).setDisplayName("�0").buildItem(), 0,1,7,8,9,17,18,19,25,26);
		inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.STAINED_GLASS_PANE).setData(8).setDisplayName("�0").buildItem(), 2,3,4,5,6,20,21,22,23,24);
		
		if(BuildFFA.getInstance().getModus().equalsIgnoreCase("KitBuildFFA")) {
			inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.STICK).setDisplayName("�6Rusher").buildItem(), 10);
			inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.IRON_SWORD).setDisplayName("�6Basedef").buildItem(), 13);
			inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.BOW).setDisplayName("�6Spammer").buildItem(), 16);
		} else {
			inventoryCreator.setItems(ItemBuilder.modify().setMaterial(Material.STONE_SWORD).setDisplayName("�6Oldschool").buildItem(), 13);
		}
		
		player.openInventory(inventoryCreator.getInventory());
	}
	
	public void openSortierungInventory(Player player, String kit) {
		InventoryCreator inventoryCreator = InventoryCreator.createInventory("�6" + kit, 4*9);
		InventoryData currentData = BuildFFA.getInstance().getPlayerStats().get(player.getUniqueId()).getInventoryData(kit);
		
		for(Integer integer : currentData.getInventoryStacks().keySet()) {
			ItemStack newStack = currentData.getInventoryStacks().get(integer).clone();
			newStack.setAmount(1);
			inventoryCreator.setItems(newStack, integer);
		}
		
		player.openInventory(inventoryCreator.getInventory());
	}

}
