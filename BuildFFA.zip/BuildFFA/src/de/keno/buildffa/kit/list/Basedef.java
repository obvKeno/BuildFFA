package de.keno.buildffa.kit.list;

import java.util.Map;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import com.google.common.collect.Maps;

import de.bwtraining.serverapi.builder.ItemBuilder;
import de.keno.buildffa.kit.Kit;

public class Basedef implements Kit {
	
	private Map<Integer, ItemStack> items = Maps.newHashMap();

	@Override
	public String getID() {
		return "Basedef";
	}

	@Override
	public void registerKit() {
		items.put(0, ItemBuilder.modify().setMaterial(Material.GOLD_SWORD).setUnbreakable(true).setDisplayName("�6Schwert").addEnchant(Enchantment.DAMAGE_ALL, 1).buildItem());
		items.put(1, ItemBuilder.modify().setMaterial(Material.WEB).setDisplayName("�6Web").buildItem());
		items.put(2, ItemBuilder.modify().setMaterial(Material.FISHING_ROD).setUnbreakable(true).setDisplayName("�6Angel").buildItem());
		items.put(8, ItemBuilder.modify().setMaterial(Material.SANDSTONE).setAmount(64).setDisplayName("�6Block").buildItem());
	}

	@Override
	public Map<Integer, ItemStack> getDefaultItems() {
		return items;
	}

}
