package de.keno.buildffa.kit;

import java.util.Map;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import com.google.common.collect.Maps;

import de.bwtraining.serverapi.builder.ItemBuilder;
import de.keno.buildffa.kit.list.Basedef;
import de.keno.buildffa.kit.list.OldSchool;
import de.keno.buildffa.kit.list.Rusher;
import de.keno.buildffa.kit.list.Spammer;

public class KitManager {
	
	private Map<String, Kit> kits = Maps.newHashMap();
	
	private Map<String, ItemStack> itemName = Maps.newHashMap();
	private Map<ItemStack, String> nameItem = Maps.newHashMap();
	
	public KitManager() {
		OldSchool oldSchool = new OldSchool();
		oldSchool.registerKit();
		
		Basedef basedef = new Basedef();
		basedef.registerKit();
		
		Rusher rusher = new Rusher();
		rusher.registerKit();
		
		Spammer spammer = new Spammer();
		spammer.registerKit();
		
		kits.put(oldSchool.getID(), oldSchool);
		kits.put(basedef.getID(), basedef);
		kits.put(rusher.getID(), rusher);
		kits.put(spammer.getID(), spammer);
		
		registerItemsNames();
		registerNameItems();
	}
	
	public Kit getKitData(String kit) {
		if(!kits.containsKey(kit)) {
			return null;
		}
		
		return kits.get(kit);
	}

	private void registerItemsNames() {
		this.itemName.put("Schwert", ItemBuilder.modify().setMaterial(Material.GOLD_SWORD).setUnbreakable(true).setDisplayName("�6Schwert").addEnchant(Enchantment.DAMAGE_ALL, 1).buildItem());
		this.itemName.put("Web", ItemBuilder.modify().setMaterial(Material.WEB).setDisplayName("�6Web").buildItem());
		this.itemName.put("Bogen", ItemBuilder.modify().setMaterial(Material.BOW).setUnbreakable(true).addEnchant(Enchantment.ARROW_KNOCKBACK, 1).addEnchant(Enchantment.ARROW_INFINITE, 1).setDisplayName("�6Bogen").buildItem());
		this.itemName.put("Pfeil", ItemBuilder.modify().setMaterial(Material.ARROW).setDisplayName("�6Pfeil").buildItem());
		this.itemName.put("Block", ItemBuilder.modify().setMaterial(Material.SANDSTONE).setAmount(64).setDisplayName("�6Block").buildItem());
		this.itemName.put("Stick", ItemBuilder.modify().setMaterial(Material.STICK).setUnbreakable(true).setDisplayName("�6Stick").addEnchant(Enchantment.KNOCKBACK, 1).buildItem());
		this.itemName.put("Angel", ItemBuilder.modify().setMaterial(Material.FISHING_ROD).setUnbreakable(true).setDisplayName("�6Angel").buildItem());
	}

	private void registerNameItems() {
		this.nameItem.put(this.itemName.get("Schwert"), "Schwert");
		this.nameItem.put(this.itemName.get("Web"), "Web");
		this.nameItem.put(this.itemName.get("Bogen"), "Bogen");
		this.nameItem.put(this.itemName.get("Pfeil"), "Pfeil");
		this.nameItem.put(this.itemName.get("Block"), "Block");
		this.nameItem.put(this.itemName.get("Stick"), "Stick");
		this.nameItem.put(this.itemName.get("Angel"), "Angel");
	}
	
	public ItemStack getItemStack(String name) {
		if(!this.itemName.containsKey(name)) {
			return new ItemStack(Material.AIR);
		}
		return this.itemName.get(name);
	}
	
	public String getItemName(ItemStack itemStack) {
		if(!this.nameItem.containsKey(itemStack)) {
			return itemStack.getItemMeta().clone().getDisplayName().replace("�6", "");
		}
		return this.nameItem.get(itemStack);
	}
	
}
