package de.keno.buildffa.kit;

import java.util.Map;

import org.bukkit.inventory.ItemStack;

public interface Kit {

	String getID();
	
	void registerKit();
	
	Map<Integer, ItemStack> getDefaultItems();
	
}
