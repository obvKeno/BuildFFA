package de.keno.buildffa.data;

import java.util.Map;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import com.google.common.collect.Maps;

import de.bwtraining.serverapi.ServerAPI;

public class StatsData {
	
	private String kit;
	private long kills;
	private long deaths;
	private boolean itemsSet = false;
	
	private Map<String, InventoryData> playerInventory = Maps.newHashMap();
	
	public StatsData(long kills, long deaths, String kit) {
		this.kills = kills;
		this.deaths = deaths;
		this.kit = kit;
	}
	
	public void addInventoryItemStack(String kit, Integer slot, ItemStack item) {
		InventoryData inventoryData = null;
		if(playerInventory.containsKey(kit)) {
			inventoryData = playerInventory.get(kit);
			inventoryData.getInventoryStacks().put(slot, item);
		} else {
			inventoryData = new InventoryData();
			inventoryData.getInventoryStacks().put(slot, item);
		}
		playerInventory.put(kit, inventoryData);
	}
	
	public boolean isItemsSet() {
		return itemsSet;
	}
	
	public String getKit() {
		return kit;
	}
	
	public void setKit(String kit) {
		this.kit = kit;
	}
	
	public void setItemsSet(boolean itemsSet) {
		this.itemsSet = itemsSet;
	}
	
	public void addKill(Player player) {
		this.kills += 1;
		
		ServerAPI.getInstance().getPlayerDatas().get(player.getUniqueId()).addCoins(player, 15);
	}
	
	public void addDeath() {
		this.deaths += 1;
	}
	
	public long getKills() {
		return kills;
	}
	
	public long getDeaths() {
		return deaths;
	}

	public String getKD() {
		if (deaths == 0 && kills == 0) {
			return "0";
		} else if (deaths == 0 && kills != 0) {
			return "" + kills;
		} else {
			double KD = (double) kills / (double) deaths;
			KD = KD * 100;
			KD = Math.round(KD);
			KD = KD / 100;
			return "" + KD;
		}
	}
	
	public void clearInventoryData(String kit) {
		if(playerInventory.containsKey(kit)) {
			playerInventory.remove(kit);
		}
	}
	
	public InventoryData getInventoryData(String kit) {
		if(!playerInventory.containsKey(kit)) {
			return null;
		}
		
		return playerInventory.get(kit);
	}

}
