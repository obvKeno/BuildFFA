package de.keno.buildffa.data;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;

import de.bwtraining.serverapi.location.LocationManager;
import net.minecraft.server.v1_8_R3.NBTTagCompound;

public class ServerData {
	
	private LocationManager locationManager;
	private Location spawnLocation, deathLocation, dropLocation, changerLocation;
	private Entity entity = null;
	
	public ServerData() {
		this.locationManager = new LocationManager("BuildFFA");
		
		if(this.locationManager.getLocation("Spawn") != null) {
			this.spawnLocation = this.locationManager.getLocation("Spawn");
		}
		if(this.locationManager.getLocation("Death") != null) {
			this.deathLocation = this.locationManager.getLocation("Death");
		}
		if(this.locationManager.getLocation("Drop") != null) {
			this.dropLocation = this.locationManager.getLocation("Drop");
		}
		if(this.locationManager.getLocation("Changer") != null) {
			this.changerLocation = this.locationManager.getLocation("Changer");
		}
	}
	
	private void freezeEntity(Entity en){
        net.minecraft.server.v1_8_R3.Entity nmsEn = ((CraftEntity) en).getHandle();
        NBTTagCompound compound = new NBTTagCompound();
        nmsEn.c(compound);
        compound.setByte("NoAI", (byte) 1);
        nmsEn.f(compound);
    }
	
	public void createVillager() {
		if(entity == null) {
			entity = Bukkit.getWorld("world").spawnEntity(this.changerLocation, EntityType.VILLAGER);
			entity.setCustomName("�eShop");
			entity.setCustomNameVisible(true);
				
			freezeEntity(entity);
			
			Entity isAlive = null;
			for(Entity entity : Bukkit.getWorld("world").getEntities()) {
				if(entity instanceof Villager) {
					if(entity.getLocation().distance(this.changerLocation) < 10) {
						isAlive = entity;
					}
				}
			}
			if(isAlive == null) {
				entity = null;
			}
		}
	}
	
	public Location getSpawnLocation() {
		return spawnLocation;
	}
	
	public Location getDeathLocation() {
		return deathLocation;
	}
	
	public Location getDropLocation() {
		return dropLocation;
	}

}
