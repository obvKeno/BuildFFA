package de.keno.buildffa.data;

import java.util.Map;

import org.bukkit.inventory.ItemStack;

import com.google.common.collect.Maps;

public class InventoryData {

	private Map<Integer, ItemStack> inventoryStacks;
	
	public InventoryData() {
		inventoryStacks = Maps.newHashMap();
	}
	
	public Map<Integer, ItemStack> getInventoryStacks() {
		return inventoryStacks;
	}
	
}
